// Sample e-commerce data used by the AI Customer Support Agent.
// In a real project this would come from a database / API.

const PRODUCTS = [
  { id: "P001", name: "Wireless Bluetooth Earbuds", price: 1499, stock: 42, category: "Electronics" },
  { id: "P002", name: "Smart Fitness Watch", price: 2999, stock: 15, category: "Electronics" },
  { id: "P003", name: "Men's Running Shoes", price: 1899, stock: 0, category: "Footwear" },
  { id: "P004", name: "Cotton Casual T-Shirt", price: 499, stock: 120, category: "Clothing" },
  { id: "P005", name: "Stainless Steel Water Bottle", price: 349, stock: 60, category: "Home & Kitchen" },
];

const ORDERS = {
  ORD1001: { product: "Wireless Bluetooth Earbuds", status: "Shipped", eta: "2 days" },
  ORD1002: { product: "Smart Fitness Watch", status: "Out for Delivery", eta: "Today" },
  ORD1003: { product: "Cotton Casual T-Shirt", status: "Delivered", eta: "Delivered on 12 Sep" },
  ORD1004: { product: "Men's Running Shoes", status: "Processing", eta: "4 days" },
};

const FAQS = {
  "return policy": "You can return any product within 7 days of delivery, provided it is unused and in original packaging.",
  "refund": "Refunds are processed within 5-7 business days after the returned item passes quality check.",
  "shipping": "We offer free shipping on orders above ₹499. Standard delivery takes 3-5 business days.",
  "payment methods": "We accept UPI, credit/debit cards, net banking, and cash on delivery (COD).",
  "cancel order": "You can cancel an order before it is shipped, from the 'My Orders' section.",
  "contact support": "You can reach our human support team at support@example.com or call 1800-000-000 (9AM-9PM).",
};
