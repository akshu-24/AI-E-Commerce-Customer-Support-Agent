/* ============================================================
   AI E-Commerce Customer Support Agent — client-side chatbot
   Pure HTML/CSS/JS, no backend required.
   ============================================================ */

// ---------- Render product grid ----------
function renderProducts() {
  const grid = document.getElementById("product-grid");
  grid.innerHTML = PRODUCTS.map((p) => `
    <div class="product-card">
      <h3>${p.name}</h3>
      <p class="price">₹${p.price}</p>
      <p class="stock ${p.stock === 0 ? "out" : ""}">
        ${p.stock === 0 ? "Out of stock" : p.stock + " in stock"}
      </p>
    </div>
  `).join("");
}
renderProducts();

// ---------- Chatbot logic ----------
function findOrder(message) {
  const match = message.toUpperCase().match(/(ORD\d{3,})/);
  if (match) {
    const orderId = match[1];
    const order = ORDERS[orderId];
    if (order) {
      return `Order ${orderId} (${order.product}) is currently '${order.status}'. Expected: ${order.eta}.`;
    }
    return `Sorry, I couldn't find any order with ID ${orderId}. Please double-check the order number.`;
  }
  return null;
}

function findProduct(message) {
  const msg = message.toLowerCase();
  const match = PRODUCTS.find(
    (p) =>
      msg.includes(p.name.toLowerCase()) ||
      p.name.toLowerCase().split(" ").some((word) => word.length > 3 && msg.includes(word))
  );
  if (match) {
    const stockInfo = match.stock > 0 ? "In stock" : "Out of stock";
    return `${match.name} costs ₹${match.price}. Status: ${stockInfo} (${match.stock} units).`;
  }
  return null;
}

function findFAQ(message) {
  const msg = message.toLowerCase();

  for (const key in FAQS) {
    if (msg.includes(key)) return FAQS[key];
  }

  const keywordMap = {
    return: "return policy",
    refund: "refund",
    ship: "shipping",
    deliver: "shipping",
    pay: "payment methods",
    cancel: "cancel order",
    human: "contact support",
    agent: "contact support",
    help: "contact support",
  };
  for (const word in keywordMap) {
    if (msg.includes(word)) return FAQS[keywordMap[word]];
  }
  return null;
}

function fallbackReply() {
  return "I'm not fully sure about that one. You can ask me about order status " +
    "(e.g. 'Where is ORD1001?'), product prices, or our return/refund/shipping policies. " +
    "For anything else, type 'contact support'.";
}

function getBotReply(message) {
  const trimmed = message.trim();
  if (!trimmed) return "Please type your question — I'm happy to help!";

  const greetings = ["hi", "hello", "hey", "vanakkam"];
  if (greetings.includes(trimmed.toLowerCase())) {
    return "Hi! 👋 I'm your AI support agent. Ask me about orders, products, or policies (returns/refunds/shipping).";
  }

  return (
    findOrder(trimmed) ||
    findFAQ(trimmed) ||
    findProduct(trimmed) ||
    fallbackReply()
  );
}

// ---------- Chat UI wiring ----------
const chatForm = document.getElementById("chat-form");
const chatInput = document.getElementById("chat-input");
const chatWindow = document.getElementById("chat-window");

function addMessage(text, sender) {
  const div = document.createElement("div");
  div.className = sender === "user" ? "user-msg" : "bot-msg";
  div.textContent = text;
  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function handleUserMessage(message) {
  addMessage(message, "user");
  // Small delay to feel like the bot is "thinking"
  setTimeout(() => {
    addMessage(getBotReply(message), "bot");
  }, 300);
}

chatForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const message = chatInput.value.trim();
  if (!message) return;
  handleUserMessage(message);
  chatInput.value = "";
});

document.querySelectorAll(".qr-btn").forEach((btn) => {
  btn.addEventListener("click", () => handleUserMessage(btn.dataset.msg));
});
