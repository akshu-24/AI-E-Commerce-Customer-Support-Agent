# AI E-Commerce Customer Support Agent (HTML/CSS/JS)

A pure front-end AI-style customer support chatbot for an e-commerce website.
No backend, no server, no build tools — just open `index.html` in a browser,
or host it free on **GitHub Pages**.

## Features
- 🤖 Chat widget that answers customer queries
- 📦 Order status lookup (e.g. "Where is my order ORD1001?")
- 🛍️ Product price & stock lookup
- ❓ FAQ handling (returns, refunds, shipping, payment methods, cancellations)
- ⚡ Quick-reply buttons for common questions

## Tech Stack
- HTML5
- CSS3
- Vanilla JavaScript (no frameworks, no dependencies)

## Project Structure
```
ai-ecommerce-support-html/
├── index.html     # Page structure
├── style.css      # Styling
├── data.js        # Sample products, orders, FAQs
├── script.js      # Chatbot logic + UI wiring
└── README.md
```

## Run Locally
Just double-click `index.html`, or run a tiny local server:
```bash
# Python
python -m http.server 8000
# then open http://localhost:8000
```

Try asking the bot:
- "Where is my order ORD1001?"
- "What is your return policy?"
- "How much is the Smart Fitness Watch?"
- "How can I cancel an order?"

## Upload to GitHub

```bash
cd ai-ecommerce-support-html
git init
git add .
git commit -m "Initial commit: AI E-Commerce Customer Support Agent"
git branch -M main
git remote add origin https://github.com/<your-username>/ai-ecommerce-support-html.git
git push -u origin main
```
(Create an empty repo first at https://github.com/new)

## Free Live Demo with GitHub Pages
1. Push the code to GitHub (steps above).
2. Go to your repo → **Settings** → **Pages**.
3. Under "Branch", select `main` and `/ (root)`, then Save.
4. Your live link will be `https://<your-username>.github.io/ai-ecommerce-support-html/`

## Future Improvements
- Connect to a real product/order API
- Add typing indicator animation
- Add voice input support
- Sentiment-based response tone
